-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 23, 2024 at 01:08 PM
-- Server version: 8.0.30
-- PHP Version: 8.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `driving_study_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` bigint UNSIGNED NOT NULL,
  `licence_type_id` int NOT NULL,
  `chapter_id` int NOT NULL,
  `language_id` int NOT NULL,
  `lesson` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `video_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `paid_status` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `licence_type_id`, `chapter_id`, `language_id`, `lesson`, `topic_name`, `topic_description`, `video_url`, `paid_status`, `created_at`, `updated_at`) VALUES
(1, 4, 1, 1, 'Road Sign', 'Mandatory sign', '<p>safsdg fghfgj ghjkjh h</p>', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/ZkZeFelPmYc?si=BjweyUlFkxyZjHsY\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', 0, '2024-08-23 22:33:00', '2024-08-25 05:37:43'),
(4, 4, 1, 2, 'রাস্তা সাইন', 'বাধ্যতামূলক চিহ্ন', '<p>বাধ্যতামূলক চিহ্ন বাধ্যতামূলক চিহ্ন বাধ্যতামূলক চিহ্ন বাধ্যতামূলক চিহ্ন</p>', NULL, 0, '2024-08-23 22:54:49', '2024-08-24 00:09:45'),
(5, 4, 1, 1, 'Road Sign', 'Optional Sign', '<p>Optional SignOptional SignOptional SignOptional Sign</p>', NULL, 0, '2024-08-23 23:42:37', '2024-08-23 23:42:37'),
(7, 4, 1, 2, 'রাস্তা সাইন', 'ঐচ্ছিক চিহ্ন', '<p>ঐচ্ছিক চিহ্ন ঐচ্ছিক চিহ্ন ঐচ্ছিক চিহ্ন ঐচ্ছিক চিহ্ন ঐচ্ছিক চিহ্ন&nbsp;</p>', NULL, 0, '2024-08-24 00:09:25', '2024-08-24 00:09:25'),
(8, 4, 1, 1, 'sample', 'sample topic', '<p>sample topicsample topicsample topic</p>', NULL, 0, '2024-08-24 02:00:41', '2024-08-24 02:01:40');

-- --------------------------------------------------------

--
-- Table structure for table `chapters`
--

CREATE TABLE `chapters` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `language_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chapters`
--

INSERT INTO `chapters` (`id`, `name`, `language_id`, `created_at`, `updated_at`) VALUES
(1, 'First Chapter', 1, '2024-08-23 10:52:29', '2024-08-23 10:52:29'),
(3, 'Second Chapter', 1, '2024-08-25 06:01:20', '2024-08-25 06:01:20');

-- --------------------------------------------------------

--
-- Table structure for table `chapter_groups`
--

CREATE TABLE `chapter_groups` (
  `id` bigint UNSIGNED NOT NULL,
  `chapter_id` int NOT NULL,
  `language_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chapter_groups`
--

INSERT INTO `chapter_groups` (`id`, `chapter_id`, `language_id`, `name`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'First Chapter', '2024-08-23 10:52:29', '2024-08-24 00:05:13'),
(2, 1, 2, 'প্রথম অধ্যায়', '2024-08-23 10:52:41', '2024-08-23 10:52:41'),
(5, 3, 1, 'Second Chapter', '2024-08-25 06:01:20', '2024-08-25 06:01:20'),
(6, 3, 2, 'দ্বিতীয় অধ্যায়', '2024-08-25 06:01:38', '2024-08-25 06:01:38');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `name`, `code`, `created_at`, `updated_at`) VALUES
(1, 'English', 'EN', NULL, NULL),
(2, 'Bangla', 'BN', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `licencetypes`
--

CREATE TABLE `licencetypes` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `licencetypes`
--

INSERT INTO `licencetypes` (`id`, `name`, `created_at`, `updated_at`) VALUES
(3, 'Car', '2024-08-20 00:20:10', '2024-08-20 00:20:10'),
(4, 'Motor Bike', '2024-08-20 00:20:31', '2024-08-20 00:20:31'),
(5, 'Mini bus', '2024-08-20 00:20:39', '2024-08-20 00:20:39');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2024_08_18_143747_create_roles_table', 1),
(6, '2024_08_18_143758_create_permissions_table', 1),
(7, '2024_08_18_143812_create_permission_roles_table', 1),
(8, '2024_08_20_050523_create_licencetypes_table', 2),
(9, '2024_08_20_064648_create_languages_table', 3),
(10, '2024_08_20_231440_create_chapters_table', 4),
(12, '2024_08_21_041821_create_books_table', 5),
(14, '2024_08_22_053818_create_questions_table', 6),
(15, '2024_08_23_140309_create_chapter_groups_table', 7),
(16, '2024_08_24_074756_add_licence_type_id_to_questions_table', 8),
(17, '2024_08_25_043205_add_columns_to_users_table', 9),
(18, '2024_08_25_084136_create_packages_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banner` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `selling_price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duration_value` int NOT NULL,
  `duration_unit` enum('day','month','year') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `name`, `slug`, `banner`, `description`, `price`, `selling_price`, `duration_value`, `duration_unit`, `status`, `created_at`, `updated_at`) VALUES
(2, 'Nice package', 'nice-package', 'upload/package_images/811019490.package.png', 'This is our nice package. It\'s duration is 1 year.', '2000', '1800', 1, 'year', 0, '2024-08-25 03:55:48', '2024-08-25 05:50:40');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `groupby` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `slug`, `groupby`, `created_at`, `updated_at`) VALUES
(1, 'user', 'user', 0, NULL, NULL),
(2, 'role', 'role', 1, NULL, NULL),
(3, 'edit role', 'editrole', 1, NULL, NULL),
(6, 'edit user', 'edituser', 0, NULL, NULL),
(7, 'delete user', 'deleteuser', 0, NULL, NULL),
(8, 'licence type', 'licencetype', 2, NULL, NULL),
(9, 'licence type edit', 'editlicencetype', 2, NULL, NULL),
(10, 'licence type delete', 'deletelicencetype', 2, NULL, NULL),
(11, 'licence type create', 'createlicencetype', 2, NULL, NULL),
(12, 'user create', 'createuser', 0, NULL, NULL),
(13, 'create role', 'createrole', 1, NULL, NULL),
(14, 'delete role', 'deleterole', 1, NULL, NULL),
(15, 'chapter', 'chapter', 3, NULL, NULL),
(16, 'createchapter', 'createchapter', 3, NULL, NULL),
(17, 'editchapter', 'editchapter', 3, NULL, NULL),
(18, 'deletechapter', 'deletechapter', 3, NULL, NULL),
(19, 'book', 'book', 4, NULL, NULL),
(20, 'createbook', 'createbook', 4, NULL, NULL),
(21, 'editbook', 'editbook', 4, NULL, NULL),
(22, 'deletebook', 'deletebook', 4, NULL, NULL),
(23, 'viewbook', 'viewbook', 4, NULL, NULL),
(24, 'questions', 'questions', 5, NULL, NULL),
(25, 'create question', 'createquestion', 5, NULL, NULL),
(26, 'edit question', 'editquestion', 5, NULL, NULL),
(27, 'delete question', 'deletequestion', 5, NULL, NULL),
(28, 'createchaptergroup', 'createchaptergroup', 3, NULL, NULL),
(29, 'view question', 'viewquestion', 5, NULL, NULL),
(30, 'profile', 'profile', 6, NULL, NULL),
(31, 'password', 'password', 6, NULL, NULL),
(32, 'packages', 'packages', 7, NULL, NULL),
(33, 'create package', 'createpackage', 7, NULL, NULL),
(34, 'edit package', 'editpackage', 7, NULL, NULL),
(35, 'delete package', 'deletepackage', 7, NULL, NULL),
(36, 'view package', 'viewpackage', 7, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `permission_roles`
--

CREATE TABLE `permission_roles` (
  `id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED DEFAULT NULL,
  `permission_id` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_roles`
--

INSERT INTO `permission_roles` (`id`, `role_id`, `permission_id`, `created_at`, `updated_at`) VALUES
(118, 4, 8, '2024-08-20 05:06:30', '2024-08-20 05:06:30'),
(119, 4, 9, '2024-08-20 05:06:30', '2024-08-20 05:06:30'),
(120, 4, 10, '2024-08-20 05:06:30', '2024-08-20 05:06:30'),
(121, 4, 11, '2024-08-20 05:06:30', '2024-08-20 05:06:30'),
(143, 5, 8, '2024-08-20 05:19:06', '2024-08-20 05:19:06'),
(144, 5, 9, '2024-08-20 05:19:06', '2024-08-20 05:19:06'),
(255, 2, 1, '2024-08-21 05:32:51', '2024-08-21 05:32:51'),
(256, 2, 2, '2024-08-21 05:32:51', '2024-08-21 05:32:51'),
(846, 1, 1, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(847, 1, 6, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(848, 1, 7, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(849, 1, 12, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(850, 1, 2, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(851, 1, 3, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(852, 1, 13, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(853, 1, 14, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(854, 1, 8, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(855, 1, 9, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(856, 1, 10, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(857, 1, 11, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(858, 1, 15, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(859, 1, 16, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(860, 1, 17, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(861, 1, 18, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(862, 1, 28, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(863, 1, 20, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(864, 1, 21, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(865, 1, 22, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(866, 1, 23, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(867, 1, 19, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(868, 1, 25, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(869, 1, 26, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(870, 1, 27, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(871, 1, 24, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(872, 1, 29, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(873, 1, 30, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(874, 1, 31, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(875, 1, 32, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(876, 1, 33, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(877, 1, 34, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(878, 1, 35, '2024-08-25 06:00:15', '2024-08-25 06:00:15'),
(879, 1, 36, '2024-08-25 06:00:15', '2024-08-25 06:00:15');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` bigint UNSIGNED NOT NULL,
  `book_id` bigint UNSIGNED NOT NULL,
  `chapter_id` bigint UNSIGNED NOT NULL,
  `language_id` bigint UNSIGNED NOT NULL,
  `licence_type_id` bigint UNSIGNED NOT NULL,
  `lesson` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `option1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `option2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `option3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `option4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correct_ans` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `difficulty_level` enum('easy','medium','hard') COLLATE utf8mb4_unicode_ci NOT NULL,
  `paid_status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `book_id`, `chapter_id`, `language_id`, `licence_type_id`, `lesson`, `question_text`, `option1`, `option2`, `option3`, `option4`, `correct_ans`, `difficulty_level`, `paid_status`, `created_at`, `updated_at`) VALUES
(1, 4, 1, 2, 4, 'রাস্তা সাইন', 'নিম্নলিখিত কোনটি প্রত্যেক চালকের জন্য বাধ্যতামূলক চিহ্ন?', 'সতর্কভাবে গাড়ি চালানো যাতে এক্সিডেন্ট বর্জন করা যায়।', 'সম্পূর্ণ গতিতে গাড়ি চালানো।', 'অন্যকে পিছনে ফেলার প্রবণতা নিয়ে গাড়ি চালানো।', 'উপরের কোনটি নয় ।', 'option1', 'easy', 0, '2024-08-24 22:20:57', '2024-08-24 22:20:57'),
(2, 1, 1, 1, 4, 'Road Sign', 'which following is the mandatory sign for every driver?', 'Drive carefully to avoid accident.', 'Drive with full speed.', 'Drive with overtaking tendency.', 'None of them.', 'option1', 'easy', 0, '2024-08-24 22:22:51', '2024-08-24 22:22:51');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'admin', NULL, '2024-08-19 05:00:35'),
(2, 'user', NULL, NULL),
(3, 'manager', NULL, NULL),
(4, 'Chief guest', '2024-08-20 05:06:30', '2024-08-20 05:06:30'),
(5, 'Visitor', '2024-08-20 05:08:09', '2024-08-20 05:08:09');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zipcode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` int NOT NULL DEFAULT '2',
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `language_id` int NOT NULL,
  `licence_type_id` int NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile_number`, `password`, `country`, `zipcode`, `address`, `role_id`, `remember_token`, `created_at`, `updated_at`, `language_id`, `licence_type_id`, `image`) VALUES
(1, 'admin', 'admin@gmail.com', '475187', '$2y$12$97ICAkB3PtLtM0aCMUqlcuLcD7wr9xoJnrMqDlOkkKtr5jUsi2kY2', 'Australia', 'xxc', '6391 Elgin St. Celina, Delaware 10299', 1, NULL, NULL, '2024-08-25 00:22:02', 0, 0, 'upload/user_images/1286484470.jeet - Copy.jpg'),
(2, 'user', 'user@gmail.com', NULL, '$2y$12$4RyYYuo/fB2AcDluomc81uYbx5vwu1zXW/m5DD3pSwvs5TSgjin5e', NULL, NULL, NULL, 2, NULL, NULL, '2024-08-20 04:09:11', 2, 3, 'upload/user_images/704937212.salman (3).jpg'),
(3, 'manager', 'manager@gmail.com', NULL, '$2y$12$4RyYYuo/fB2AcDluomc81uYbx5vwu1zXW/m5DD3pSwvs5TSgjin5e', NULL, NULL, NULL, 3, NULL, NULL, '2024-08-21 05:35:17', 0, 0, 'upload/user_images/1375019832.g4.jpg'),
(4, 'karim', 'karim@gmail.com', NULL, '$2y$12$t9JjMpentYnpk.Pz6lStyOYqfz0OqGg0Cn658prjC/5cTcuPwr2ZW', NULL, NULL, NULL, 2, NULL, '2024-08-20 01:20:19', '2024-08-20 04:08:35', 2, 4, 'upload/user_images/451641296.sarukh (2).jpg'),
(5, 'rakib', 'rakib@gmail.com', NULL, '$2y$12$OGRIZ/T3q900yUY86i84o.BS4rhxoBwe4l9WekNBpy4P8rcuVUUhm', NULL, NULL, NULL, 2, NULL, '2024-08-20 01:21:23', '2024-08-20 04:26:48', 2, 4, 'upload/user_images/260865886.g4.jpg'),
(8, 'khan', 'khan@gmail.com', NULL, '$2y$12$yyTlsUof.SJMJX4jRmXBKuL3vmRbtQsixlemiBxPnq6VsrrypGwxO', NULL, NULL, NULL, 2, NULL, '2024-08-21 03:18:47', '2024-08-24 00:24:43', 1, 4, 'upload/user_images/2129505738.sarukh (2).jpg'),
(9, 'khan2', 'khan2@gmail.com', NULL, '$2y$12$sSbflGUd0EMgnh/py3BryO3Ye3Rt417xv7rFsOBfgYG52k7I5FivC', NULL, NULL, NULL, 2, NULL, '2024-08-21 03:22:11', '2024-08-24 00:24:54', 1, 4, 'upload/user_images/1138867655.g1.jpg'),
(10, 'talukdar', 'talukdar@gmail.com', NULL, '$2y$12$6hsX8i/flItcneItTWnN3eWJgEir9O1tKHZgcf89LJLLXSICqAcJi', NULL, NULL, NULL, 2, NULL, '2024-08-21 03:28:02', '2024-08-24 00:25:10', 1, 4, 'upload/user_images/948829256.jeet - Copy.jpg'),
(11, 'sayem', 'sayem@gmail.com', NULL, '$2y$12$bC24rSK8wFtmSa0w/WCMPuBSWv33amxbbwbn8bgGK4RW0gCK478zC', NULL, NULL, NULL, 2, NULL, '2024-08-21 03:29:49', '2024-08-21 05:35:28', 1, 4, 'upload/user_images/124657571.g5 - Copy.jpg'),
(12, 'nazmul', 'nazmul@gmail.com', NULL, '$2y$12$uRQ6J8QkphO3Bu00NultFOaq6gqqslzItFY0Sy2VxmfGpSD0X6sLe', NULL, NULL, NULL, 2, NULL, '2024-08-22 05:23:19', '2024-08-24 00:25:30', 2, 4, 'upload/user_images/1201825816.salman (3).jpg'),
(13, 'Jafor', 'jafor@gmail.com', '475187', '$2y$12$axqVJjoG5XMC8c2gqWOPouQOSfDY1CcEUiRb71FdPcoOS9ywR/pUe', 'Bangladesh', 'xxc', 'Boraigram, Natore, Rajshahi.', 2, NULL, '2024-08-25 00:36:59', '2024-08-25 00:36:59', 2, 4, 'upload/user_images/148074198.jeet - Copy.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chapters`
--
ALTER TABLE `chapters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chapter_groups`
--
ALTER TABLE `chapter_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `licencetypes`
--
ALTER TABLE `licencetypes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `packages_slug_unique` (`slug`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`),
  ADD UNIQUE KEY `permissions_slug_unique` (`slug`);

--
-- Indexes for table `permission_roles`
--
ALTER TABLE `permission_roles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permission_roles_role_id_foreign` (`role_id`),
  ADD KEY `permission_roles_permission_id_foreign` (`permission_id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `chapters`
--
ALTER TABLE `chapters`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `chapter_groups`
--
ALTER TABLE `chapter_groups`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `licencetypes`
--
ALTER TABLE `licencetypes`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `permission_roles`
--
ALTER TABLE `permission_roles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=880;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `permission_roles`
--
ALTER TABLE `permission_roles`
  ADD CONSTRAINT `permission_roles_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `permission_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
